<?php

include_once ELAINE_RESTAURANT_SHORTCODES_PATH.'/working-hours/functions.php';
include_once ELAINE_RESTAURANT_SHORTCODES_PATH.'/working-hours/working-hours.php';