<?php

include_once ELAINE_CORE_SHORTCODES_PATH . '/awards/functions.php';
include_once ELAINE_CORE_SHORTCODES_PATH . '/awards/awards.php';