<div class="edgtf-image-marquee-holder">
    <div class="edgtf-image-marquee">
        <div class="edgtf-image edgtf-original">
            <img src="<?php echo wp_get_attachment_url($image); ?>" alt="<?php echo get_the_title($image) ?>" />
        </div>
        <div class="edgtf-image edgtf-aux">
            <img src="<?php echo wp_get_attachment_url($image); ?>" alt="<?php echo get_the_title($image) ?>" />
        </div>
    </div>
</div>