<div class="edgtf-process-holder <?php echo esc_attr( $holder_classes ); ?>">
	<div class="edgtf-process-inner"><div class="edgtf-process-line"></div>
		<?php echo do_shortcode( $content ); ?>
	</div>
</div>