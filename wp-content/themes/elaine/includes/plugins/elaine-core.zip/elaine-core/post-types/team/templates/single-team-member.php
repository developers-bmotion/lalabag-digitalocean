<?php

get_header();

elaine_edge_get_title();

do_action('elaine_edge_action_before_main_content');

elaine_core_get_single_team();

get_footer();