<?php

include_once ELAINE_CORE_CPT_PATH . '/team/team-register.php';
include_once ELAINE_CORE_CPT_PATH . '/team/helper-functions.php';