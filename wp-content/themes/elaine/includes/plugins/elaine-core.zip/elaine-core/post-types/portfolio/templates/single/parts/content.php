<div class="edgtf-ps-info-item edgtf-ps-content-item">
	<h3 itemprop="name" class="edgtf-ps-content-title entry-title">
		<a itemprop="url" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
	</h3>
	<?php the_content(); ?>
</div>